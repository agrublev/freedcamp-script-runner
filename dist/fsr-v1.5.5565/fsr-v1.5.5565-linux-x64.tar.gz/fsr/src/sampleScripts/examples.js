const chalk = require("chalk");
console.log(
    `${chalk.red.underline.bold(
        "RUNS JSUNS JSUNS JSUNS JSUNS JSUNS JSUNS JSUNS JSUNS JSUNS JSUNS JSUNS JS"
    )}`
);
setTimeout(() => {
    console.log(`${chalk.green("RUNS JSUNS JSUNS JSUNS JSUNS JSUNS JSUNS JasdasdsJS")}`);
}, 4000);
console.log("RUNS JS");
