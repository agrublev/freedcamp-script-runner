#!/usr/bin/env bash

npm version patch -f
npm publish
#npm i -g fscripts@latest
