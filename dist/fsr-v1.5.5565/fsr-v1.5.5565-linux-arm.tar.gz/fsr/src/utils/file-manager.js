const chalk = require("chalk");

fs.writeFileSync(tempFile, script, "utf8");
