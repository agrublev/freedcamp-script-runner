# 🚀 fsr — Landing Page Copy

---

## HERO SECTION

### 🏷️ Eyebrow Tag
`npm i -g fscr` — free & open source

### 📢 Headline
# Your scripts. Documented. Runnable. In one Markdown file. 📄⚡

### 🔤 Subheadline
`package.json` can't hold docs. `README` can't run scripts.
**fsr** puts them in the same file — so they can never drift apart again.

### 🎬 Hero CTA
```
[ npm i -g fscr ]   [ ⭐ Star on GitHub ]
```

### 💬 Social Proof Line
*"Our team loves it — and nobody outside had heard of it yet. That ends now."*

---

## 😤 PROBLEM SECTION

### Section Header
## Sound familiar? 👀

### Problem Cards (3-column)

**Card 1 — The Mystery Scripts** 🕵️
> You clone a new repo. There are 40 scripts in `package.json`. The README mentions three of them. Nobody knows what the rest do. The one person who wrote them is on PTO.

**Card 2 — The Wrong Deploy** 💀
> You run `build:prod` thinking it's the dev build. Staging goes down. It's 9:23am on your first day. The Slack message appears: *"Hey, why is staging down?"*

**Card 3 — The Drift** 💔
> You update the scripts. You forget to update the README. Three months later, nobody trusts the docs. They just try scripts and hope. This is fine. 🔥

### Problem Closer
**You're not bad at documentation. The tools just make it impossible.**
`package.json` has no room for docs. `README` can't run anything. You end up maintaining two things that drift apart on day one — and stay that way forever.

---

## ✅ SOLUTION SECTION

### Section Header
## One file. Docs AND runner. Problem solved. 🎉

### Solution Explanation
**fsr** introduces `fscripts.md` — a Markdown file that is simultaneously your documentation AND your script runner.

Write scripts in plain Markdown. Add descriptions. Organize into sections. Run them directly from the file. The docs and the runner are the same thing now. **They literally cannot drift apart.**

### 3-Step Onboarding Visual

```
Step 1 ✨                Step 2 📝               Step 3 🎯
─────────────────        ─────────────────        ─────────────────
npm i -g fscr            fsr generate             fsr

Install fsr              Auto-imports all         Interactive picker
globally                 your package.json        appears. Pick a
                         scripts into             script. Run it.
One command.             fscripts.md              No memorizing.
Done.                    with docs stubs.         No digging.
```

---

## ⚡ FEATURES SECTION

### Section Header
## Everything your scripts deserved all along 💅

---

### Feature 1 — 🎯 The Interactive Picker
**Just run `fsr`. That's it.**

An interactive list of every script — with its human-readable description — appears right in your terminal. Arrow keys to navigate. Enter to run. No man pages. No README hunting. No Slack messages asking "which script starts the dev server?" ever again.

```bash
$ fsr

? Choose a script to run: (Use arrow keys)
❯ 🚀 start:dev       — Start the development server with hot reload
  🏗️  build:prod      — Full production build (grab a ☕)
  🧹 clean            — Remove build artifacts
  🔐 encrypt:secrets  — Encrypt .env files before committing
  📦 deploy:staging   — Deploy to staging environment
```

---

### Feature 2 — 🤯 Full JavaScript Blocks in Markdown
**Not just one-liners. Real scripts. In your Markdown.**

Write complete, multi-line JavaScript directly inside `fscripts.md` using standard code blocks. Run them with `fsr run [task]`. The Markdown IS the script. No separate files. No imports. Just write and run.

````markdown
### check-env
Validates all required environment variables before starting. 🔍

```javascript
const required = ['DATABASE_URL', 'API_KEY', 'NODE_ENV'];
const missing = required.filter(k => !process.env[k]);
if (missing.length) {
  console.error(`❌ Missing: ${missing.join(', ')}`);
  process.exit(1);
}
console.log('✅ All environment variables present!');
```
````

---

### Feature 3 — ✨ Auto-Generate from package.json
**Already have scripts? Import them in one command.**

```bash
fsr generate
```

Pulls every script from your `package.json` into a fresh `fscripts.md` with documentation stubs. Your existing workflow doesn't change — it just gets superpowers. 💪

---

### Feature 4 — ⚡ Parallel & Sequential Execution
**Built-in. No extra tools. No extra config.**

```bash
# Start everything at once ⚡
fsr run-p start:web start:api start:worker

# Run in order 🔗
fsr run-s clean build:prod deploy:staging
```

---

### Feature 5 — 🔌 Plugin System
**Hook into before and after any script execution.**

Plugins appear right in the `fsr` interactive picker. Want to clear the cache before every script runs? Auto-notify Slack after a deploy? Check environment variables before a build? Write a plugin, hook it in, done. It fires automatically, every time.

```javascript
// 🧹 auto-cache-cleaner plugin
export default {
  name: 'cache-cleaner',
  hooks: {
    'pre-task': async ({ taskName }) => {
      console.log(`🧹 Clearing cache before ${taskName}...`);
      await clearCache();
    }
  }
}
```

---

### Feature 6 — 🔐 File Encryption
**Password-protect your secrets without leaving the terminal.**

```bash
fsr encrypt    # 🔐 encrypt your .env files
fsr decrypt    # 🔓 decrypt when you need them
fsr encryption # 🔑 interactive encrypt/decrypt menu
```

Never accidentally commit secrets again. Never email `.env` files again. Never explain to your CTO why credentials were in git history again. 😬

---

### Feature 7 — 🩺 System Doctor
**Diagnose and fix your environment without googling.**

```bash
fsr doctor          # run diagnostics
fsr doctor --fix    # auto-fix what can be fixed
fsr doctor --json   # CI-friendly JSON output
```

---

### Feature 8 — 💅 And More...

| Feature | Command |
|---|---|
| 📑 Auto Table of Contents | `fsr toc` |
| 🏷️ Version bump + beautify | `fsr bump` |
| 📈 Smart package upgrades | `fsr upgrade` |
| 🐚 Shell tab completions | `fsr completion install` |
| 📊 Cache management | `fsr cache stats / clear / list` |
| 🌿 Git branch validation | `fsr branch` |
| 🗑️ Clear task history | `fsr clear` |

---

## 🆚 COMPARISON SECTION

### Section Header
## The honest comparison 👀

| | Raw `package.json` | README + npm scripts | Makefile | **fsr** |
|---|---|---|---|---|
| Docs next to scripts | ❌ | ❌ | ⚠️ | ✅ |
| Interactive picker | ❌ | ❌ | ❌ | ✅ |
| Full JS script blocks | ❌ | ❌ | ❌ | ✅ |
| Parallel execution | ❌ | ❌ | ⚠️ | ✅ |
| Plugin hooks | ❌ | ❌ | ❌ | ✅ |
| File encryption | ❌ | ❌ | ❌ | ✅ |
| Zero config setup | ✅ | ✅ | ❌ | ✅ |
| JS/Node native | ✅ | ✅ | ❌ | ✅ |
| Docs can drift | ✅ (always) | ✅ (always) | ⚠️ | ❌ never |

**The others aren't really alternatives. Devs just suffer without fsr.** 😅

---

## 💬 TESTIMONIAL SECTION

### Section Header
## Built by a team that got tired of suffering 😤

### Quote
> *"We built fsr because our own team had the same problem everyone has. The README is always lying. The `package.json` is always cryptic. We decided the answer wasn't better documentation tooling OR a better script runner — it was making them the same file."*
>
> — **The fsr team** 🛠️

### Internal Proof Line
**Our whole team uses fsr on every project. We wouldn't ship it if we didn't.**

---

## 🚀 FINAL CTA SECTION

### Section Header
## Three commands. That's it. 🎯

```bash
npm i -g fscr   # install
fsr generate    # import your existing scripts
fsr             # pick one and run it 🚀
```

### CTA Buttons
```
[ 📦 npm i -g fscr ]   [ ⭐ GitHub ]   [ 📄 Docs ]
```

### Closer Line
**No config. No setup. No more "ask Mike what the scripts do."** 🙌

---

## 🦶 FOOTER COPY

**fsr** — Freedcamp Script Runner
Your scripts. In plain English. ✨

`npm i -g fscr` · [GitHub](#) · [npm](#) · [Docs](#)

*Made with ☕ and mild frustration at `package.json`*

---

## 📐 PAGE NOTES FOR DESIGN

- **Hero background:** Dark terminal aesthetic — deep navy or near-black. Monospaced font for code snippets.
- **Accent color:** Bright green `#27AD60` (matches the chalk color used in fsr's own CLI output 🎨)
- **Secondary text:** Muted lavender `#9F9FA5` (matches fsr's description text color)
- **Tone:** Cheeky but not unprofessional. The emojis are intentional. Devs like devs.
- **Terminal mockups:** Show the actual `fsr` interactive picker — it's the hero feature visually
- **Animations:** Typewriter effect on the hero code block. Interactive picker with animated selection.
- **Social proof:** GitHub stars, npm weekly downloads — add when live
