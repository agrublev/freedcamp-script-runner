### Usage

Install dependencies

```bash
npm i
```

Run application

```bash
npm start
```
