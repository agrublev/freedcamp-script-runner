### Usage

> This example requires Chrome 72 (Chrome Canary) to function.

Install dependencies

```bash
npm i
```

Run application

```bash
npm start
```

Optionally package as executable

```bash
pkg package.json
```
