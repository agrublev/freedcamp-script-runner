### Usage

Install dependencies

```bash
npm i
```

Run application

```bash
npm start
```

Optionally package as executable

```bash
pkg package.json
```
