'use strict';

const gulp = require('gulp');
let browserSync = require('browser-sync').create();

// Load plugins
let less = require("gulp-less");


gulp.task('styles', function () {
	return gulp.src('./styles/*.less')
	.pipe(less())
	.pipe(gulp.dest('./styles'))
	.pipe(browserSync.reload({stream: true}));
});

gulp.task('browser-sync', function () {
	browserSync.init({
		server:{},
		notify: {
			styles: [
				'display: block;',
				'position: fixed;',
				'z-index: 899999;',
				'right: 0px;',
				'bottom: 0px;',
				'background-color: rgba(0,0,0,0.5);',
				'color: white;',
				'padding: 1em 4em;',
				'height: 50px;',
				'min-width: 300px;',
				'box-shadow: 0px 0px 28px 0px rgba(0,0,0,0.57);',
				'text-align: center;',
				'font-size: 16px;'
			]
		},
		ghostMode: {
			clicks: false,
			forms: false,
			scroll: false
		}
	});
});


gulp.task('watch', function () {
	gulp.watch('./styles/*.less', ['styles']);
	gulp.watch(['./views/*.html', './index.html', './script/**/*.js']).on('change', browserSync.reload);
});

gulp.task('default', ['styles','browser-sync'], function () {
	gulp.start('watch');
});
