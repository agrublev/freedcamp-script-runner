# formeApp

# First get npm running and stuff you need to open terminal!

## may need
```bash
npm i -g gulp
```

# then just
```bash
npm i
```

# and every type from now on to run it (auto opens browser and reloads)
```bash
gulp
```
